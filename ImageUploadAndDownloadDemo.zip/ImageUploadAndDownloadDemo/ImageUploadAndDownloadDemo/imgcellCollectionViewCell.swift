//
//  imgcellTableViewCell.swift
//  ImageUploadAndDownloadDemo
//
//  Created by Kush on 20/11/17.
//  Copyright © 2017 icreate. All rights reserved.
//

import UIKit

class imgcellCollectionViewCell: UICollectionViewCell{

    //Mark:- outlet
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblProductPrice: UILabel!
    
    
}
