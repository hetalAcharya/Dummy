//
//  ViewController.swift
//  ImageUploadAndDownloadDemo
//
//  Created by Kush on 16/11/17.
//  Copyright © 2017 icreate. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    //Mark:- Variable Declaration
    
    var imgPicker:UIImagePickerController = UIImagePickerController()
    var OnClickPopupGesture:UITapGestureRecognizer!
    var activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    
    
    //Mark:- Outlet
    
    @IBOutlet weak var txtProductName: UITextField!
    @IBOutlet weak var txtProductPrice: UITextField!
    @IBOutlet weak var imgProductImage: UIImageView!
    
    //Mark:- Button Upload Action
    @IBAction func btnUploadPost(_ sender: Any) {
        activityIndicator.startAnimating()
        ImagePost()
    }
    
    
    @IBAction func btnBrowse(_ sender: Any) {
        alertBoxShow()
    }
    
    
    @IBAction func btnViewImage(_ sender: Any) {
        
        performSegue(withIdentifier: "ToVIewImageFromImageUpload", sender: nil)
    }
    
    
    //Mark:- Override Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    //Mark:- Alert View In Browse to Image
    
    func alertBoxShow() {
        let ImageAlert = UIAlertController()
        ImageAlert.addAction(UIAlertAction(title: "Camera", style: .default, handler: nil))
        ImageAlert.addAction(UIAlertAction(title: "Gallary", style: .default, handler: gallary))
        ImageAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(ImageAlert, animated: true, completion: nil)
    }
    
    //Gallary Method
    
    func gallary(sender:UIAlertAction) {
        imgPicker.delegate = self
        imgPicker.sourceType = .photoLibrary
        
        self.present(imgPicker, animated: true, completion: nil)
    }
    
    
    //mark:- image picker delegate method
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imgProductImage.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    
    //Mark:- Image Upload Method
    
    private func ImagePost() {
        
        let reqUrl:URL = URL(string: "https://hoven-differences.000webhostapp.com/product_insert.php")!
        let parameter = ["pname":txtProductName.text!,"price":txtProductPrice.text!,"image":"img_\(txtProductName.text!)"] as [String : Any]
        
        do {
            let reqData = try JSONSerialization.data(withJSONObject: parameter, options: .prettyPrinted)
            
            var request = URLRequest(url: reqUrl, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60)
            request.httpMethod = "POST"
            request.httpBody = reqData
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: request, completionHandler: { (resData, response, error) in
                if (error != nil){
                    print(error.debugDescription)
                }else{
                    do {
                        
                        let resDict = try JSONSerialization.jsonObject(with: resData!, options: .allowFragments)
                        print(resDict)
                        
                        DispatchQueue.main.async {
                            self.parseData(lid: resDict as! [String : Any])
                        }
                    }catch{
                        print(exception())
                    }
                }
            })
            task.resume()
        }
        catch{
            print(exception())
            activityIndicator.stopAnimating()
        }
    }
    
    // Parsing Data in variable and Store NSUser Default
    
    private func parseData(lid:[String:Any]) {
        
        let responseID = lid["id"] as? Int
        
        print(responseID!)
        
        ImageUploadID(Id: responseID)
    }
    
    
    func ImageUploadID(Id:Int!) {
        
        let imgURl = URL(string: "https://hoven-differences.000webhostapp.com/img_upload.php?id=" + String(Id))
        
        var request = URLRequest(url: imgURl! as URL)
        
        request.httpMethod = "POST"
        
        let boundary = "ImageBoundry"
        
        request.setValue("multipart/form-data; boundary=\(boundary)",
            
            forHTTPHeaderField: "Content-Type")
        
        if (imgProductImage.image == nil) {
            return
        }
            
        else {
            let image_data = UIImagePNGRepresentation(imgProductImage.image!)
            
            let body = NSMutableData()
            
            let filename = "img-\(String(Id))" + ".png"
            
            body.append("\r\n--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            
            body.append("Content-Disposition:form-data; name=\"fileUpload\"; filename=\"\(filename)\"\r\n".data(using: String.Encoding.utf8)!)
            
            body.append("Content-Type: application/octet-stream\r\n\r\n".data(using:String.Encoding.utf8)!)
            
            body.append(image_data!)
            
            body.append("\r\n".data(using: String.Encoding.utf8)!)
            
            body.append("--\(boundary)--\r\n".data(using:String.Encoding.utf8)!)
            
            request.httpBody = body as Data
            
            let session = URLSession.shared
            
            let task = session.dataTask(with: request as URLRequest) {
                
                (data, response, error) in
                
                guard let _:Data = data, let _:URLResponse = response , error
                    
                    == nil else {
                        print("error")
                        return
                }
                
                let dataString = String(data: data!, encoding:String.Encoding(rawValue: String.Encoding.utf8.rawValue))
                print(dataString!)
                
                self.clearText()
                
            }
            task.resume()
        }
    }
    
    func clearText() {
        activityIndicator.stopAnimating()
        txtProductName.text = ""
        txtProductPrice.text = ""
        imgProductImage.image = nil
    }
    
    
}


