//
//  ImageViewViewController.swift
//  ImageUploadAndDownloadDemo
//
//  Created by Kush on 20/11/17.
//  Copyright © 2017 icreate. All rights reserved.
//

import UIKit

class ImageViewViewController: UIViewController, UICollectionViewDataSource {

    //Mark:- Outlet
    @IBOutlet weak var cvImageView: UICollectionView!
    
    var img:UIImageView?
    
    //Mark:- Override Method
    override func viewDidLoad() {
        super.viewDidLoad()
        cvImageView.dataSource = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mark:- Collection View Data Source Methods
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imgcell", for: indexPath) as! imgcellCollectionViewCell
        
        cell.lblProductName.text = ""
        cell.lblProductPrice.text = ""
        
        
        //here image url name geting in modal class and view image in collection item
        let url=URL(string: "https://hoven-differences.000webhostapp.com/product_images/img-131.png" )
        let data=NSData(contentsOf: url!)
        if data != nil {
            cell.imgView.image=UIImage(data: data as! Data)
        }
        
        return cell
    }
    

    
    func PreparingData() {
        let reqUrl:URL = URL(string: "https://hoven-differences.000webhostapp.com/product_insert.php")!
        
        do {
            
            var request = URLRequest(url: reqUrl, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60)
            request.httpMethod = "GET"
//            request.httpBody = reqData
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: request, completionHandler: { (resData, response, error) in
                if (error != nil){
                    print(error.debugDescription)
                }else{
                    do {
                        
                        let resDict = try JSONSerialization.jsonObject(with: resData!, options: .allowFragments)
                        print(resDict)
                        
//                        DispatchQueue.main.async {
//                            self.parseData(lid: resDict as! [String : Any])
//                        }
                    }catch{
                        print(exception())
                    }
                }
            })
            task.resume()
        }
        catch{
            print(exception())
        }
    }
    
    // Parsing Data in variable and Store NSUser Default
    
//    private func parseData(lid:[String:Any]) {
//        
//        let responseID = lid["id"] as? Int
//        
//        print(responseID!)
//        
//    }


}
